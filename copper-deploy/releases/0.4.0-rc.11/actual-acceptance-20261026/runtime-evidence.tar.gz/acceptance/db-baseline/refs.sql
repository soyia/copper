SELECT 'inbound_attachment', id, storage_path, file_size, sha256
FROM inbound_attachment
WHERE storage_path IS NOT NULL AND storage_path <> ''
UNION ALL
SELECT 'inbound_review_snapshot_attachment', id, storage_path, file_size, sha256
FROM inbound_review_snapshot_attachment
WHERE storage_path IS NOT NULL AND storage_path <> ''
UNION ALL
SELECT 'business_evidence_attachment', id, storage_path, file_size, sha256
FROM business_evidence_attachment
WHERE storage_path IS NOT NULL AND storage_path <> ''
UNION ALL
SELECT 'tax_invoice_import_batch', id, source_storage_path, source_file_size, source_file_sha256
FROM tax_invoice_import_batch
WHERE source_storage_path IS NOT NULL AND source_storage_path <> ''
UNION ALL
SELECT 'bank_statement_import_batch', id, source_storage_path, source_file_size, source_file_sha256
FROM bank_statement_import_batch
WHERE source_storage_path IS NOT NULL AND source_storage_path <> ''
UNION ALL
SELECT 'accounting_archive_batch', id, storage_path, archive_bytes, archive_sha256
FROM accounting_archive_batch
WHERE storage_path IS NOT NULL AND storage_path <> ''
ORDER BY 1, 2;
SET @copper_optional_sql = IF(EXISTS(
  SELECT 1 FROM information_schema.COLUMNS
  WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'electronic_credential' AND COLUMN_NAME = 'storage_path'
), CONVERT(0x53454c4543542027656c656374726f6e69635f63726564656e7469616c272c2069642c2073746f726167655f706174682c2066696c655f73697a652c20736f757263655f66696c655f7368613235362046524f4d20656c656374726f6e69635f63726564656e7469616c2057484552452073746f726167655f70617468204953204e4f54204e554c4c20414e442073746f726167655f70617468203c3e202727 USING utf8mb4), 'SELECT NULL WHERE 1=0');
PREPARE copper_optional_statement FROM @copper_optional_sql;
EXECUTE copper_optional_statement;
DEALLOCATE PREPARE copper_optional_statement;
SET @copper_optional_sql = IF(EXISTS(
  SELECT 1 FROM information_schema.COLUMNS
  WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'electronic_credential_verification' AND COLUMN_NAME = 'proof_storage_path'
), CONVERT(0x53454c4543542027656c656374726f6e69635f63726564656e7469616c5f766572696669636174696f6e272c2069642c2070726f6f665f73746f726167655f706174682c2070726f6f665f66696c655f73697a652c2070726f6f665f7368613235362046524f4d20656c656374726f6e69635f63726564656e7469616c5f766572696669636174696f6e2057484552452070726f6f665f73746f726167655f70617468204953204e4f54204e554c4c20414e442070726f6f665f73746f726167655f70617468203c3e202727 USING utf8mb4), 'SELECT NULL WHERE 1=0');
PREPARE copper_optional_statement FROM @copper_optional_sql;
EXECUTE copper_optional_statement;
DEALLOCATE PREPARE copper_optional_statement;
SET @copper_optional_sql = IF(EXISTS(
  SELECT 1 FROM information_schema.COLUMNS
  WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'product_import_job' AND COLUMN_NAME = 'source_storage_path'
), CONVERT(0x53454c454354202770726f647563745f696d706f72745f6a6f62272c2069642c20736f757263655f73746f726167655f706174682c20736f757263655f66696c655f73697a652c20736f757263655f66696c655f7368613235362046524f4d2070726f647563745f696d706f72745f6a6f6220574845524520736f757263655f73746f726167655f70617468204953204e4f54204e554c4c20414e4420736f757263655f73746f726167655f70617468203c3e202727 USING utf8mb4), 'SELECT NULL WHERE 1=0');
PREPARE copper_optional_statement FROM @copper_optional_sql;
EXECUTE copper_optional_statement;
DEALLOCATE PREPARE copper_optional_statement;
SET @copper_optional_sql = IF(EXISTS(
  SELECT 1 FROM information_schema.COLUMNS
  WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'document_intake_batch' AND COLUMN_NAME = 'storage_path'
), CONVERT(0x53454c4543542027646f63756d656e745f696e74616b655f6261746368272c2069642c2073746f726167655f706174682c2066696c655f73697a652c207368613235362046524f4d20646f63756d656e745f696e74616b655f62617463682057484552452073746f726167655f70617468204953204e4f54204e554c4c20414e442073746f726167655f70617468203c3e202727 USING utf8mb4), 'SELECT NULL WHERE 1=0');
PREPARE copper_optional_statement FROM @copper_optional_sql;
EXECUTE copper_optional_statement;
DEALLOCATE PREPARE copper_optional_statement;
