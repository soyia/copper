SET SESSION group_concat_max_len = 10485760;
SELECT GROUP_CONCAT(
  CONCAT(
    'SELECT ', QUOTE(TABLE_NAME),
    ' AS table_name, COUNT(*) AS row_count FROM `',
    REPLACE(TABLE_NAME, '`', '``'), '`'
  )
  ORDER BY TABLE_NAME
  SEPARATOR ' UNION ALL '
) INTO @copper_count_sql
FROM information_schema.TABLES
WHERE TABLE_SCHEMA = DATABASE() AND TABLE_TYPE = 'BASE TABLE';
SET @copper_count_sql = CONCAT(@copper_count_sql, ' ORDER BY table_name');
PREPARE copper_count_statement FROM @copper_count_sql;
EXECUTE copper_count_statement;
DEALLOCATE PREPARE copper_count_statement;
