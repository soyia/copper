#!/usr/bin/env python3
"""Synthetic-only unit checks for receipt/site guards; no actual phase is run."""
import importlib.util,json,os,shutil,sys,tempfile,unittest
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch

sys.dont_write_bytecode=True
ROOT=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('rc11_phase_checks',ROOT/'phase-runner.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)

class GuardChecks(unittest.TestCase):
 def setUp(self):
  self.temp=tempfile.TemporaryDirectory(prefix='rc11-synthetic-guard-');self.addCleanup(self.temp.cleanup);self.p=Path(self.temp.name)
  self.archive=self.p/'synthetic.copperbak';self.archive.write_bytes(b'SYNTHETIC_UNIT_BYTES_NOT_AN_ENCRYPTED_BACKUP')
  self.status={'backupId':'synthetic-unit-id','sha256':m.H(self.archive)}
  self.receipt=self.p/'receipt.json';self.report=self.p/'report.json'
  self.doc={'formatVersion':'copper-key-backup-verification/v1','result':'PASSED','backupId':self.status['backupId'],'backupSha256':m.H(self.archive),'proof':'SYNTHETIC_NOT_A_REAL_OFFLINE_PROOF'}
  self.report_doc={'status':'PASS','system':'Darwin','businessDataSource':'SYNTHETIC_SITE_ONLY','backupId':self.status['backupId'],'backupSha256':m.H(self.archive),'offlineToolSha256':m.TARGET['runtimeFileHashes']['copper-key-offline']}
  self.calls=[]
 def files(self):
  m.save(self.receipt,self.doc);self.report_doc['receiptSha256']=m.H(self.receipt);m.save(self.report,self.report_doc)
 def invoke(self):
  with patch.object(m,'check_archive',return_value=(self.archive,self.status)),patch.object(m,'EVIDENCE',self.p),patch.object(m,'run',side_effect=lambda argv:self.calls.append(argv)):
   m.record_mac_receipt('full',SimpleNamespace(receipt=self.receipt,mac_report=self.report))
 def rejected(self):
  with self.assertRaises(RuntimeError):self.invoke()
  self.assertFalse(self.calls)
 def test_matching_unit_receipt_reaches_official_record_command_only(self):
  self.files();self.invoke();self.assertEqual(self.calls[0][-4:],['backup','key','record-restore-test',self.receipt])
 def test_other_backup_id_rejected_before_official_command(self):
  self.doc['backupId']='wrong-unit-id';self.files();self.rejected()
 def test_receipt_old_archive_hash_rejected(self):
  self.doc['backupSha256']='0'*64;self.files();self.rejected()
 def test_macos_report_for_other_receipt_rejected(self):
  self.files();self.report_doc['receiptSha256']='1'*64;m.save(self.report,self.report_doc);self.rejected()
 def test_non_mac_report_rejected(self):
  self.report_doc['system']='Linux';self.files();self.rejected()
 def test_other_offline_tool_rejected(self):
  self.report_doc['offlineToolSha256']='2'*64;self.files();self.rejected()
 def test_mutated_archive_rejected(self):
  self.files();self.archive.write_bytes(b'SYNTHETIC_CHANGED_BYTES');self.rejected()
 def test_old_site_and_version_rejected_before_runtime_access(self):
  env=self.p/'copper.env'
  for site,version in [('copper-acceptance-rc10','0.4.0-rc.11'),('copper-acceptance-rc11','0.4.0-rc.10')]:
   with self.subTest(site=site,version=version):
    env.write_text(f'COPPER_SITE_ID={site}\nCOPPER_RELEASE_VERSION={version}\n')
    with patch.object(m,'ENV',env),self.assertRaises(RuntimeError):m.config()
 def test_old_reader_bytes_rejected(self):
  env=self.p/'copper.env';env.write_text('COPPER_SITE_ID=copper-acceptance-rc11\nCOPPER_RELEASE_VERSION=0.4.0-rc.11\nCOPPER_ETC_DIR=/etc/copper\nCOPPER_VAR_DIR=/var/lib/copper\n')
  deploy=self.p/'deploy';deploy.mkdir();f=deploy/'scripts/backup-chain.py';f.parent.mkdir();f.write_text('SYNTHETIC_OLD_READER_BYTES')
  with patch.object(m,'ENV',env),patch.object(m,'DEPLOY',deploy),patch.dict(m.TARGET,{'runtimeFileHashes':{'scripts/backup-chain.py':m.TARGET['runtimeFileHashes']['scripts/backup-chain.py']}}),self.assertRaises(RuntimeError):m.config()

if __name__=='__main__':
 result=unittest.TextTestRunner(verbosity=2).run(unittest.defaultTestLoader.loadTestsFromTestCase(GuardChecks))
 print(json.dumps({'scope':'OFFLINE_SYNTHETIC_GUARDS_ONLY_NOT_RUNTIME_OR_MAC_DECRYPT_EVIDENCE','checks':result.testsRun,'failures':len(result.failures),'errors':len(result.errors),'networkUsed':False,'databaseUsed':False}))
 raise SystemExit(not result.wasSuccessful())
