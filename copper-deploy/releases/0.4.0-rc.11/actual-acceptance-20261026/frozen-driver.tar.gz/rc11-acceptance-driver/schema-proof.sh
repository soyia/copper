#!/usr/bin/env bash
# Read-only proof on the caller-owned current Compose site. Does not contact SSH.
set -Eeuo pipefail
[[ $# -ge 4 && $# -le 5 ]] || { echo 'usage: schema-proof.sh DEPLOY_ROOT ENV_FILE STATE_JSON NEW_OUTPUT_DIR [baseline|incremental|continued]' >&2; exit 2; }
acceptance_deploy="$1" acceptance_env="$2" acceptance_state="$3" acceptance_output="$4" acceptance_phase="${5:-}"
[[ -d "$acceptance_deploy" && -f "$acceptance_env" && -f "$acceptance_state" && ! -e "$acceptance_output" ]] || { echo 'invalid owned inputs or output already exists' >&2; exit 1; }
source "$acceptance_deploy/scripts/lib.sh"
ENV_FILE="$acceptance_env"
source "$acceptance_deploy/scripts/verification-sql.sh"
mkdir -m 0700 "$acceptance_output"

mysql_read() {
  compose_cmd exec -T mysql sh -c \
    'MYSQL_PWD="$(cat /run/secrets/mysql_root_password)" exec mysql -uroot -D copper_v2 --batch --raw --skip-column-names'
}
python3 - "$acceptance_state" "$acceptance_output/fixture.sql" "$(required_env_value COPPER_SITE_ID)" "$acceptance_phase" <<'PY'
import json,pathlib,sys
state=json.loads(pathlib.Path(sys.argv[1]).read_text())
if state.get('synthetic') is not True or state.get('siteId')!=sys.argv[3]: raise SystemExit('state/site mismatch')
phase=sys.argv[4] or state['phase']; facts=state['phases'][phase]
def integer(value):
 if type(value) is not int or value<=0: raise SystemExit('unsafe fixture id')
 return value
partner,product,warehouse,purchase,batch=(integer(state[k]) for k in ('partner','product','warehouse','purchase','batch'))
sales=','.join(str(integer(value)) for value in facts['sales'])
queries=[
("database_version",'SELECT VERSION()'),
("schema",'SELECT version FROM flyway_schema_history WHERE success=1 ORDER BY installed_rank DESC LIMIT 1'),
("foreign_keys",'SELECT COUNT(*) FROM information_schema.REFERENTIAL_CONSTRAINTS WHERE CONSTRAINT_SCHEMA=DATABASE()'),
("quantity",f'SELECT quantity_available FROM inventory_batch WHERE id={batch}'),
("amount_cost",f'SELECT amount_cost FROM inventory_batch WHERE id={batch}'),
("stock_quantity",f'SELECT quantity_available FROM stock_balance WHERE product_id={product} AND warehouse_id={warehouse}'),
("stock_amount_cost",f'SELECT amount_cost FROM stock_balance WHERE product_id={product} AND warehouse_id={warehouse}'),
("receivable",f'SELECT SUM(receivable_amount-received_amount-adjusted_amount) FROM sales_order WHERE id IN ({sales})'),
("payable",f'SELECT total_amount-paid_amount FROM purchase_order WHERE id={purchase}'),
("posting_batches",f"SELECT COUNT(*) FROM business_posting_batch WHERE partner_id={partner} AND status='POSTED'"),
("vouchers",f'SELECT COUNT(*) FROM accounting_voucher WHERE business_posting_batch_id IN (SELECT id FROM business_posting_batch WHERE partner_id={partner})'),
("unbalanced_vouchers",f'SELECT COUNT(*) FROM accounting_voucher WHERE debit_total<>credit_total AND business_posting_batch_id IN (SELECT id FROM business_posting_batch WHERE partner_id={partner})'),
("generation_issues", "SELECT COUNT(*) FROM accounting_generation_issue WHERE status='OPEN'"),
("outbounds",f"SELECT COUNT(*) FROM outbound_order WHERE customer_id={partner} AND status='SHIPPED'"),
("non_trade_invalid_refs",'SELECT COUNT(*) FROM inventory_non_trade_item WHERE packaging_ref_id<=0'),
("non_trade_duplicate_refs",'SELECT COUNT(*) FROM (SELECT packaging_ref_id FROM inventory_non_trade_item GROUP BY packaging_ref_id HAVING COUNT(*)>1) duplicate_refs'),
("failed_flyway",'SELECT COUNT(*) FROM flyway_schema_history WHERE success=0'),
("binlog_enabled",'SELECT @@log_bin'),
("binlog_format",'SELECT @@binlog_format'),
("binlog_row_image",'SELECT @@binlog_row_image'),
]
# Static queries plus strictly positive integer IDs only; no caller SQL is accepted.
# Wrapping arbitrary scalar metadata statements in derived aliases is unnecessary.
pathlib.Path(sys.argv[2]).write_text(''.join(query.replace('SELECT ',f"SELECT '{key}', ",1)+';\n' for key,query in queries))
PY
mysql_read < "$acceptance_output/fixture.sql" > "$acceptance_output/facts.tsv"
write_table_counts_sql "$acceptance_output/counts.sql"
write_business_totals_sql "$acceptance_output/totals.sql"
write_attachment_references_sql "$acceptance_output/refs.sql"
mysql_read < "$acceptance_output/counts.sql" > "$acceptance_output/record-counts.tsv"
mysql_read < "$acceptance_output/totals.sql" > "$acceptance_output/business-totals.tsv"
mysql_read < "$acceptance_output/refs.sql" > "$acceptance_output/attachment-references.tsv"
printf '%s\n' "SELECT k.CONSTRAINT_NAME,k.TABLE_NAME,k.COLUMN_NAME,k.REFERENCED_TABLE_NAME,k.REFERENCED_COLUMN_NAME,k.ORDINAL_POSITION,r.DELETE_RULE,r.UPDATE_RULE FROM information_schema.KEY_COLUMN_USAGE k JOIN information_schema.REFERENTIAL_CONSTRAINTS r ON r.CONSTRAINT_SCHEMA=k.CONSTRAINT_SCHEMA AND r.TABLE_NAME=k.TABLE_NAME AND r.CONSTRAINT_NAME=k.CONSTRAINT_NAME WHERE k.CONSTRAINT_SCHEMA=DATABASE() AND k.REFERENCED_TABLE_NAME IS NOT NULL ORDER BY k.TABLE_NAME,k.CONSTRAINT_NAME,k.ORDINAL_POSITION;" | mysql_read > "$acceptance_output/foreign-keys.tsv"
printf '%s\n' "SELECT TABLE_NAME,ENGINE FROM information_schema.TABLES WHERE TABLE_SCHEMA=DATABASE() AND TABLE_TYPE='BASE TABLE' ORDER BY TABLE_NAME;" | mysql_read > "$acceptance_output/table-engines.tsv"
python3 "$acceptance_deploy/scripts/restore-metadata.py" assert-core-foreign-keys 68 "$acceptance_output/foreign-keys.tsv" --table-engines "$acceptance_output/table-engines.tsv" --database-version "$(awk -F '\t' '$1=="database_version" {print $2}' "$acceptance_output/facts.tsv")"
python3 "$acceptance_deploy/scripts/restore-metadata.py" foreign-key-sql "$acceptance_output/foreign-keys.tsv" "$acceptance_output/foreign-key-checks.sql"
mysql_read < "$acceptance_output/foreign-key-checks.sql" > "$acceptance_output/foreign-key-results.tsv"
python3 - "$(required_env_value COPPER_VAR_DIR)/files" "$acceptance_output/attachment-files.tsv" <<'PY'
import pathlib,hashlib,sys
root=pathlib.Path(sys.argv[1]); rows=[]
for value in sorted(root.rglob('*')):
 if value.is_symlink(): raise SystemExit('unexpected symlink in attachment tree')
 if value.is_file(): rows.append(f'{value.relative_to(root)}\t{value.stat().st_size}\t{hashlib.sha256(value.read_bytes()).hexdigest()}\n')
pathlib.Path(sys.argv[2]).write_text(''.join(rows))
PY
python3 "$acceptance_deploy/scripts/backup-metadata.py" attachments "$acceptance_output/attachment-files.tsv" "$acceptance_output/attachment-references.tsv" "$acceptance_output/attachments.json"
python3 - "$acceptance_state" "$acceptance_output" "$acceptance_phase" <<'PY'
from decimal import Decimal as D
import json,pathlib,sys
state=json.loads(pathlib.Path(sys.argv[1]).read_text()); output=pathlib.Path(sys.argv[2]); phase=sys.argv[3] or state['phase']; expected=state['phases'][phase]
facts=dict(line.split('\t',1) for line in (output/'facts.tsv').read_text().splitlines())
assert facts['schema']=='68' and facts['database_version'].startswith('8.4.') and facts['foreign_keys']=='92', 'schema/database/FK baseline mismatch'
for key,field in [('quantity','quantity'),('stock_quantity','quantity'),('amount_cost','amountCost'),('stock_amount_cost','amountCost'),('receivable','receivable'),('payable','payable')]: assert D(facts[key])==D(expected[field]), (key,facts[key],expected[field])
for key in ('unbalanced_vouchers','generation_issues','non_trade_invalid_refs','non_trade_duplicate_refs','failed_flyway'): assert facts[key]=='0', key
assert facts['binlog_enabled']=='1' and facts['binlog_format']=='ROW' and facts['binlog_row_image']=='FULL'
assert int(facts['outbounds'])==len(expected['outbounds']), 'idempotent outbound produced duplicate document'
assert int(facts['posting_batches'])>=2+3*len(expected['outbounds'])+len(expected['receipts'])+len(expected['supplierPayments'])
assert int(facts['vouchers'])>=1+2*len(expected['outbounds'])+len(expected['receipts'])+len(expected['supplierPayments'])
orphans=[line for line in (output/'foreign-key-results.tsv').read_text().splitlines() if line and D(line.rsplit('\t',1)[-1])!=0]
assert not orphans,'foreign key orphan check failed'
attachments=json.loads((output/'attachments.json').read_text()); assert attachments['databaseReferenceCount']>=2 and attachments['fileCount']>=2
report={'format':'copper-compose-schema-proof/v1','status':'PASS','synthetic':True,'phase':phase,'schema':68,'foreignKeys':92,'facts':facts,'attachmentFiles':attachments['fileCount'],'attachmentReferences':attachments['databaseReferenceCount'],'productionVerificationSqlUsed':True,'businessSqlMutations':False}
(output/'report.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({'status':'PASS','schema':68,'foreignKeys':92,'phase':phase,'quantity':facts['quantity'],'receivable':facts['receivable'],'payable':facts['payable'],'attachmentFiles':attachments['fileCount']}))
PY
