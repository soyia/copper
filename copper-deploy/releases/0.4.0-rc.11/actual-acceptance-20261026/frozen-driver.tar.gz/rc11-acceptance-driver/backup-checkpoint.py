#!/usr/bin/env python3
"""Read-only last-success checkpoint; production backup verify/decrypt/stage remain required."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import stat


def regular(path):
    if path.is_symlink() or not path.is_file() or not stat.S_ISREG(path.stat().st_mode):
        raise RuntimeError('backup checkpoint requires ordinary files without symlinks')


def checkpoint(root, output, expected_format, different_from=()):
    root = root.resolve(strict=True)
    if not root.is_dir():
        raise RuntimeError('backup root is not a directory')
    source = root/'last-success.json'
    regular(source)
    raw = source.read_bytes()
    status = json.loads(raw)
    if status.get('formatVersion') != expected_format:
        raise RuntimeError('last-success format does not match the requested backup phase')
    name = status.get('archive')
    if not isinstance(name,str) or not re.fullmatch(r'[A-Za-z0-9][A-Za-z0-9_.-]*\.copperbak',name) or Path(name).name != name:
        raise RuntimeError('last-success archive must be a basename inside the verified backup root')
    archive, sidecar = root/name, root/(name+'.sha256')
    for path in (archive,sidecar):
        regular(path)
        if path.resolve(strict=True).parent != root:
            raise RuntimeError('backup archive or sidecar escaped its owned root')
    if type(status.get('size')) is not int or status['size'] != archive.stat().st_size:
        raise RuntimeError('last-success size differs from the actual archive')
    expected = status.get('sha256','')
    if not re.fullmatch(r'[0-9a-f]{64}',expected):
        raise RuntimeError('last-success SHA256 is invalid')
    digest=hashlib.sha256()
    with archive.open('rb') as stream:
        for part in iter(lambda:stream.read(1024*1024),b''): digest.update(part)
    if digest.hexdigest()!=expected or sidecar.read_text().split()!=[expected,name]:
        raise RuntimeError('archive/status/sidecar SHA256 mismatch')
    if not status.get('backupId'):
        raise RuntimeError('last-success backup ID is missing')
    for prior in different_from:
        regular(prior)
        if json.loads(prior.read_bytes()).get('backupId')==status['backupId']:
            raise RuntimeError('the new backup reused a prior checkpoint ID')
    if output.exists() or output.is_symlink():
        raise RuntimeError('refusing to overwrite a previous backup checkpoint')
    descriptor=os.open(output,os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o600)
    with os.fdopen(descriptor,'wb') as out: out.write(raw)
    return archive


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--backup-root',type=Path,required=True)
    parser.add_argument('--status-output',type=Path,required=True)
    parser.add_argument('--expect-format',choices=('copper-backup/v1','copper-backup/v2'),required=True)
    parser.add_argument('--different-from',type=Path,action='append',default=[])
    args=parser.parse_args()
    print(checkpoint(args.backup_root,args.status_output,args.expect_format,args.different_from))


if __name__=='__main__':main()
