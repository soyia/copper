#!/usr/bin/env python3
"""Run one authorized RC11 synthetic acceptance phase on its local server."""
import argparse, fcntl, hashlib, json, os, runpy, shutil, socket, subprocess, sys
from datetime import datetime, timezone
from pathlib import Path

HERE=Path(__file__).resolve().parent
TARGET=json.loads((HERE/'target.json').read_text())
RUNTIME=Path(TARGET['runtime']);EVIDENCE=Path(TARGET['evidence'])
DEPLOY=Path(TARGET['deploy']);ENV=Path(TARGET['envFile'])
SITE=TARGET['siteId'];CTL=[str(DEPLOY/'copperctl'),'--env-file',str(ENV)]
API=runpy.run_path(str(HERE/'api-fixture.py'))
save=API['write_private'];read_private=API['read_private']
PHASES=('bootstrap','seed','full','full-mac-receipt','advance','incremental','stage1','switch1','restored','continue','rebuild','new-full','new-full-mac-receipt','stage2','discard2','final')
STATE=RUNTIME/'fixture-state.json';CREDS=RUNTIME/'api-credentials.json';LEDGER=RUNTIME/'phase-runner-state.json';PATHS=RUNTIME/'backup-paths.json'
H=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def load(p):return json.loads(Path(p).read_text())
def require(ok,message):
 if not ok:raise RuntimeError(message)
def run(argv,capture=False):
 return subprocess.run(list(map(str,argv)),check=True,text=True,capture_output=capture).stdout if capture else subprocess.run(list(map(str,argv)),check=True)
def config():
 require(ENV.is_file() and not ENV.is_symlink(),'Expected ordinary site copper.env')
 result={}
 for line in ENV.read_text().splitlines():
  if not line.strip() or line.lstrip().startswith('#'):continue
  key,value=line.split('=',1);key=key.strip();require(key not in result,'Duplicate environment key');result[key]=value.strip()
 require(result.get('COPPER_SITE_ID')==SITE,'Wrong site ID; no action taken')
 require(result.get('COPPER_RELEASE_VERSION')==TARGET['version'],'Wrong installed release; no action taken')
 require(result.get('COPPER_ETC_DIR')=='/etc/copper' and result.get('COPPER_VAR_DIR')=='/var/lib/copper','Expected fresh default etc/var directories')
 for name,digest in TARGET['runtimeFileHashes'].items():
  p=DEPLOY/name;require(p.is_file() and not p.is_symlink() and H(p)==digest,'Installed runtime contract differs: '+name)
 return result
def roots(c):
 return Path(c['COPPER_ETC_DIR']),Path(c['COPPER_VAR_DIR']),Path(c.get('COPPER_BACKUP_DIR') or '/var/backups/copper'),Path(c.get('COPPER_RESTORE_ROOT') or '/var/lib/copper-restores')
def api(command,extra=()):
 argv=[sys.executable,HERE/'api-fixture.py',command,'--base-url',TARGET['baseUrl'],'--connect-ip','127.0.0.1','--site-id',SITE,'--credentials',CREDS,'--state',STATE]
 if command in ('bootstrap','seed','advance','continue'):argv+=['--synthetic-site-ack',SITE]
 return run(argv+list(extra))
def proof(label,phase):
 run(['bash',HERE/'schema-proof.sh',DEPLOY,ENV,STATE,EVIDENCE/('db-'+label),phase])
 require(load(EVIDENCE/('db-'+label)/'report.json')['status']=='PASS','Schema proof did not pass')
def api_verify(label,phase):
 api('verify',['--phase',phase,'--evidence',EVIDENCE/('api-'+label+'.json')])
 require(load(EVIDENCE/('api-'+label+'.json'))['status']=='PASS','API proof did not pass')
def compose_ids():
 script='source "$1/scripts/lib.sh"; ENV_FILE="$2"; compose_cmd ps -q "$3"'
 result={}
 for role in ('mysql','backend','web'):
  value=run(['bash','-c',script,'rc11-proof',DEPLOY,ENV,role],True).strip();require(value and '\n' not in value,'Missing unique site container: '+role)
  require(run(['docker','inspect','--format','{{.State.Health.Status}}',value],True).strip()=='healthy','Unhealthy site container: '+role)
  result[role]=value
 return result
def snapshot(c):
 etc,var,backup,restore=roots(c)
 directories=[etc,var/'mysql',var/'files',backup,restore/'release-recovery-rc11/rollback/mysql',restore/'release-recovery-rc11/rollback/files']
 result={'containers':compose_ids(),'directories':{},'attachments':{}}
 for p in directories:
  require(p.is_dir() and not p.is_symlink(),'Missing owned persistent directory: '+str(p));s=p.stat();result['directories'][str(p)]=[s.st_dev,s.st_ino]
 for p in sorted((var/'files').rglob('*')):
  require(not p.is_symlink(),'Attachment symlink')
  if p.is_file():result['attachments'][str(p.relative_to(var/'files'))]={'sha256':H(p),'bytes':p.stat().st_size}
 return result
def check_archive(key):
 paths=read_private(PATHS);p=Path(paths[key]);status=load(EVIDENCE/('backup-'+key+'-status.json'))
 require(p.is_file() and not p.is_symlink() and H(p)==status['sha256'],'Backup archive changed: '+key)
 require(p.with_name(p.name+'.sha256').is_file(),'Missing original backup sidecar')
 return p,status
def backup(key,kind,c):
 run(CTL+['backup','create','--purpose','manual','--type',kind])
 argv=[sys.executable,HERE/'backup-checkpoint.py','--backup-root',roots(c)[2],'--expect-format','copper-backup/v2' if kind=='incremental' else 'copper-backup/v1','--status-output',EVIDENCE/('backup-'+key+'-status.json')]
 for prior in ('full','incremental'):
  if prior!=key and (EVIDENCE/('backup-'+prior+'-status.json')).exists():argv+=['--different-from',EVIDENCE/('backup-'+prior+'-status.json')]
 archive=run(argv,True).strip();require(Path(archive).is_absolute(),'Checkpoint did not return an absolute archive path')
 paths=read_private(PATHS) if PATHS.exists() else {};paths[key]=archive;save(PATHS,paths)
 run(CTL+['backup','verify',archive])
def record_mac_receipt(key,args):
 require(args.receipt and args.mac_report,'This phase requires actual macOS receipt and safe verification report')
 archive,status=check_archive(key);receipt=read_private(args.receipt);report=load(args.mac_report)
 require(receipt.get('formatVersion')=='copper-key-backup-verification/v1' and receipt.get('result')=='PASSED','Invalid offline receipt')
 require(receipt.get('backupId')==status['backupId'] and receipt.get('backupSha256')==H(archive),'Offline receipt belongs to another backup')
 require(report.get('status')=='PASS' and report.get('system')=='Darwin' and report.get('businessDataSource')=='SYNTHETIC_SITE_ONLY','Expected actual macOS decrypt report')
 require(report.get('receiptSha256')==H(args.receipt) and report.get('backupSha256')==H(archive) and report.get('backupId')==status['backupId'],'macOS report/receipt/archive binding mismatch')
 require(report.get('offlineToolSha256')==TARGET['runtimeFileHashes']['copper-key-offline'],'macOS used a different offline verification tool')
 run(CTL+['backup','key','record-restore-test',args.receipt])
 safe_keys=('format','status','system','macOSVersion','businessDataSource','backupId','backupSha256','archiveBasename','receiptSha256','offlineToolSha256','privateKeyOrProofIncluded')
 save(EVIDENCE/('mac-'+key+'-verification.json'),{key:report[key] for key in safe_keys if key in report})
def stage(number,args,c):
 require(args.identity and args.identity.is_file() and not args.identity.is_symlink(),'Provide the synthetic server-side recovery identity file')
 require(args.identity.stat().st_mode&0o077==0,'Identity must be private 0600/0400')
 rid='release-recovery-rc11' if number==1 else 'release-rebackup-rc11';port=18081 if number==1 else 18082
 _,_,_,restore=roots(c);require(not (restore/rid).exists(),'Preserve existing restore ID evidence; do not overwrite it')
 with socket.socket() as probe:probe.bind(('127.0.0.1',port))
 archive,_=check_archive('full' if number==1 else 'new-full')
 argv=CTL+['backup','restore','stage',archive]
 if number==1:argv+=['--incremental',check_archive('incremental')[0]]
 run(argv+['--identity',args.identity,'--restore-id',rid,'--port',str(port)])
 status=json.loads(run(CTL+['backup','restore','status',rid],True));require(status['status']=='VALIDATED','Stage did not reach VALIDATED')
 dest=EVIDENCE/('stage'+str(number));require(not dest.exists(),'Stage evidence output already exists');dest.mkdir(mode=0o700)
 save(dest/'status.json',status)
 contract=restore/rid/'contract'
 for name in ('imported-result.json','staged-result.json'):
  doc=load(contract/name);require(doc.get('result')=='passed' and not doc.get('mismatches') and not doc.get('foreignKeyViolations'),'Stage comparison failed');save(dest/name,doc)
 for part in ('expected','imported','staged'):
  (dest/part).mkdir(mode=0o700)
  for name in ('schema.json','record-counts.json','business-totals.json','attachments.json','foreign-keys.tsv','foreign-keys-metadata.tsv','table-engines.tsv','flyway-history.tsv'):
   p=contract/part/name
   if p.is_file():shutil.copyfile(p,dest/part/name);os.chmod(dest/part/name,0o600)
 if number==1:
  chain=load(contract/'chain-summary.json');require(chain['chainLength']==1,'Expected one incremental');require(chain['baseBackupId']==check_archive('full')[1]['backupId'] and chain['lastBackupId']==check_archive('incremental')[1]['backupId'],'Wrong restored chain');save(dest/'chain-summary.json',chain)
 # No HTTP request or authentication is made to the VALIDATED sidecar.
def execute(phase,args,c):
 if phase=='bootstrap':
  initial=roots(c)[0]/'credentials/initial-admin.txt';run(CTL+['admin','init']);api('bootstrap',['--initial-credentials',initial]);require(not initial.exists(),'Initial credential was not destroyed')
 elif phase=='seed':api('seed',['--evidence',EVIDENCE/'api-baseline.json']);proof('baseline','baseline')
 elif phase=='full':backup('full','full',c)
 elif phase=='full-mac-receipt':record_mac_receipt('full',args)
 elif phase=='advance':api('advance',['--evidence',EVIDENCE/'api-incremental.json']);proof('incremental','incremental')
 elif phase=='incremental':backup('incremental','incremental',c)
 elif phase=='stage1':stage(1,args,c)
 elif phase=='switch1':
  run(CTL+['backup','restore','switch','release-recovery-rc11']);status=json.loads(run(CTL+['backup','restore','status','release-recovery-rc11'],True));require(status['status']=='SWITCHED','Switch did not complete');save(EVIDENCE/'switch1-status.json',status)
 elif phase=='restored':api_verify('restored','incremental');proof('restored','incremental')
 elif phase=='continue':api('continue',['--evidence',EVIDENCE/'api-continued.json']);proof('continued','continued')
 elif phase=='rebuild':
  before=snapshot(c);run(CTL+['down']);run(CTL+['up']);after=snapshot(c)
  require(all(before['containers'][k]!=after['containers'][k] for k in before['containers']),'down/up did not recreate all three containers')
  require(before['directories']==after['directories'] and before['attachments']==after['attachments'],'Persistent paths or attachment bytes changed during rebuild')
  for key in ('full','incremental'):check_archive(key)
  save(EVIDENCE/'rebuild-persistence.json',{'status':'PASS','before':before,'after':after});api_verify('rebuilt','continued');proof('rebuilt','continued')
 elif phase=='new-full':backup('new-full','full',c)
 elif phase=='new-full-mac-receipt':record_mac_receipt('new-full',args)
 elif phase=='stage2':stage(2,args,c)
 elif phase=='discard2':
  restore=roots(c)[3];rid='release-rebackup-rc11';run(CTL+['backup','restore','discard',rid,'--confirm','DISCARD '+rid]);require(not (restore/rid).exists(),'Second sidecar was not discarded');require((restore/'release-recovery-rc11/rollback/mysql').is_dir() and (restore/'release-recovery-rc11/rollback/files').is_dir(),'First switched rollback slot was lost')
 elif phase=='final':
  api_verify('final','continued');proof('final','continued')
  for key in ('full','incremental','new-full'):check_archive(key)
  restore=roots(c)[3]
  require(not (restore/'release-rebackup-rc11').exists() and all((restore/'release-recovery-rc11/rollback'/name).is_dir() for name in ('mysql','files')),'Final sidecar/retained rollback state differs')
  save(EVIDENCE/'final-acceptance-summary.json',{'status':'PASS','version':TARGET['version'],'siteId':SITE,'schema':68,'foreignKeys':92,'phase':'continued','sourceMutationMethod':'REAL_HTTP_APIS_ONLY','backupEvidence':['FULL_V1_MAC_DECRYPT','INCREMENTAL_V2_STAGE_REPLAY','RESTORE_SWITCH','CONTINUE','DOWN_UP_REBUILD','NEW_FULL_V1_MAC_DECRYPT','NEW_FULL_STAGE','SECOND_SIDECAR_DISCARD'],'firstSwitchedRollbackRetained':True,'customerAcceptanceClaimed':False,'legalApprovalClaimed':False})

def main():
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('phase',choices=(*PHASES,'list','inspect'));p.add_argument('--identity',type=Path);p.add_argument('--receipt',type=Path);p.add_argument('--mac-report',type=Path);args=p.parse_args()
 if args.phase=='list':print('\n'.join(PHASES));return
 if args.phase=='inspect':print(json.dumps(read_private(LEDGER) if LEDGER.exists() else {'status':'NOT_STARTED'},indent=2));return
 if args.phase in ('stage1','stage2') and not args.identity:p.error('stage phases require --identity pointing to the new synthetic private key file')
 if args.phase in ('full-mac-receipt','new-full-mac-receipt') and not (args.receipt and args.mac_report):p.error('receipt phases require --receipt and --mac-report from actual macOS verification')
 runpy.run_path(str(HERE/'verify-package.py'))['verify']()
 require(os.geteuid()==0,'Run this local-server phase with sudo/root')
 require(not any(k.startswith(('COPPER_TEST_','COPPER_RESTORE_TEST_','COPPER_BACKUP_TEST_')) for k in os.environ),'Test bypass/injection flags are forbidden')
 if args.phase=='switch1':require(sys.stdin.isatty() and sys.stdout.isatty(),'switch1 requires a trusted real PTY and the official typed confirmation')
 c=config();RUNTIME.mkdir(parents=True,exist_ok=True,mode=0o700);EVIDENCE.mkdir(parents=True,exist_ok=True,mode=0o700)
 require(not RUNTIME.is_symlink() and not EVIDENCE.is_symlink(),'Owned output roots cannot be symlinks')
 with (RUNTIME/'.phase-runner.lock').open('w') as lock:
  fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
  ledger=read_private(LEDGER) if LEDGER.exists() else {'format':'copper-rc11-acceptance-phases/v1','siteId':SITE,'envSha256':H(ENV),'runtimeFileHashes':TARGET['runtimeFileHashes'],'phases':{}}
  require(ledger['siteId']==SITE and ledger['envSha256']==H(ENV),'Site configuration changed; reconcile before continuing')
  require(args.phase not in ledger['phases'],'Phase already attempted; inspect checkpoints instead of repeating mutations')
  for earlier in PHASES[:PHASES.index(args.phase)]:require(ledger['phases'].get(earlier,{}).get('status')=='PASS','Missing passed phase: '+earlier)
  ledger['phases'][args.phase]={'status':'RUNNING','startedAt':datetime.now(timezone.utc).isoformat()};save(LEDGER,ledger)
  try:execute(args.phase,args,c)
  except BaseException as error:
   ledger['phases'][args.phase].update(status='FAILED_OR_UNKNOWN_REQUIRES_RECONCILIATION',errorType=type(error).__name__);save(LEDGER,ledger);raise
  ledger['phases'][args.phase].update(status='PASS',completedAt=datetime.now(timezone.utc).isoformat());save(LEDGER,ledger)
  print(json.dumps({'phase':args.phase,'status':'PASS','siteId':SITE,'version':TARGET['version']}))
if __name__=='__main__':main()
