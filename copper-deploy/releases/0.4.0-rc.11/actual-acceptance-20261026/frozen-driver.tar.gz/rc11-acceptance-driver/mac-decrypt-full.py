#!/usr/bin/env python3
"""Execute the official offline helper on actual macOS; never exports proof/key bytes."""
import argparse, hashlib, json, platform, subprocess
from pathlib import Path
import runpy

ROOT=Path(__file__).resolve().parent;TARGET=json.loads((ROOT/'target.json').read_text())
save=runpy.run_path(str(ROOT/'api-fixture.py'))['write_private']
H=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def main():
 p=argparse.ArgumentParser(description=__doc__)
 for name in ('tool','identity','archive','receipt','report'):p.add_argument('--'+name,type=Path,required=True)
 a=p.parse_args()
 if platform.system()!='Darwin':raise RuntimeError('This phase must actually execute on macOS')
 if any(x.exists() or x.is_symlink() for x in [a.receipt,a.report]):raise RuntimeError('Fresh private receipt/report paths required')
 if a.tool.is_symlink() or H(a.tool)!=TARGET['runtimeFileHashes']['copper-key-offline']:raise RuntimeError('Wrong frozen official offline helper')
 before=H(a.archive)
 subprocess.run(['python3',str(a.tool),'verify-backup','--identity',str(a.identity),'--archive',str(a.archive),'--receipt',str(a.receipt)],check=True)
 receipt=json.loads(a.receipt.read_text())
 if receipt.get('result')!='PASSED' or receipt.get('backupSha256')!=before or H(a.archive)!=before:raise RuntimeError('Actual decrypt receipt/archive mismatch')
 report={'format':'copper-macos-offline-backup-check/v1','status':'PASS','system':platform.system(),'macOSVersion':platform.mac_ver()[0],'businessDataSource':'SYNTHETIC_SITE_ONLY','backupId':receipt['backupId'],'backupSha256':before,'archiveBasename':a.archive.name,'receiptSha256':H(a.receipt),'offlineToolSha256':H(a.tool),'privateKeyOrProofIncluded':False}
 save(a.report,report);print(json.dumps(report))
if __name__=='__main__':main()
