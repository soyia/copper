# RC11：真实经营、整站增量恢复与恢复后再次备份

仅用于已授权的独立合成站点 `copper-acceptance-rc11`。这份工具包的准备不代表实际验收通过，也不代表客户签字、第三方见证或正式发布。

固定目标见 `target.json`：Backend `ecd7ee7001bf01368504c98e579f8e9c3cbe6af9`；Deploy runtime base `f74b32c`，最终冻结 metadata HEAD 由 Root 从真实发布材料绑定。版本 `0.4.0-rc.11`、schema68、92FK。已审 API/SQL/checkpoint/12项离线合同工具逐字节复用。运行器同时核对已修复恢复工具的实际文件 SHA，拒绝旧 RC10 reader。

固定路径：

```sh
D=/home/ubuntu/copper-acceptance-20261025/rc11-acceptance-driver
DEPLOY=/opt/copper/releases/0.4.0-rc.11
ENV=/etc/copper/copper.env
R=/home/ubuntu/copper-acceptance-20261025/runtime-rc11
E=/home/ubuntu/copper-acceptance-20261025/evidence/acceptance-rc11
```

Root 先完成旧 owned RC10 站点正式卸载与 cold-preserve，保留旧备份；再通过正式 RC11 guided 介质 fresh install。确认 actual 三镜像/来源和最终介质摘要，默认站点已改为 `copper-acceptance-rc11`，没有宿主 Backend8191/MySQL3306映射。使用新的合成 age key 目录并正式登记；key registration 在首个 phase 前完成。禁止把真实客户/见证人交接记为通过。私钥、API credentials、cookie 和含 proof 的原始离线回执只放私有 runtime，不进入证据包或 Git。

解包后先执行 `python3 "$D/verify-package.py"` 校验闭集。如需复跑准备阶段的离线检查，用 `python3 -B "$D/offline-contract-check.py"` 和 `python3 -B "$D/runner-offline-check.py"`，避免在冻结目录生成 Python bytecode。闭集验证不代表运行验收通过。

所有 phase 都在验收机本地由 Root 执行；本工具不建立 SSH、GitHub 代理或远程控制。运行器要求 sudo/root、正确 site/version/目录、连续完成的前置 phase；失败或未知结果会保留 ledger，拒绝盲目重发。只写本轮合成业务，使用 Web `https://18.142.134.26` 并通过 `--resolve` 连接127.0.0.1:443，保留真实证书校验。无需修改脚本执行位：

```sh
sudo python3 "$D/phase-runner.py" list
sudo python3 "$D/phase-runner.py" bootstrap
sudo python3 "$D/phase-runner.py" seed
sudo python3 "$D/phase-runner.py" full
```

bootstrap 使用 `/etc/copper/credentials/initial-admin.txt`，完成真实首次改密并确认原文件销毁。seed 通过实际 API 完成双角色单位、商品、采购入库、销售出库、原件+审核快照附件、部分收付款与出库幂等；自动凭证由真实业务生成。随后调用 `bash schema-proof.sh`，不依赖传输时保留执行位，不补写 SQL 业务或生成凭证。

`full` 创建正式 `copper-backup/v1`，保存 `E/backup-full-status.json`，通过正式 outer verify。实际路径保存在私有 `R/backup-paths.json`；`last-success.json.archive` 是 basename，helper 按真实备份根拼接并核对 SHA/大小/sidecar。保留源 archive 与原 sidecar，不改写内容。

接着必须在**真实 macOS**解密。Root 把该 full 和同名 `.sha256` sidecar、冻结 RC11 `copper-key-offline` 拷到 Mac 自有目录；使用此次新合成 key 的 Mac 私钥原件。下面占位路径由 Root 填入，不把私钥内容或 receipt proof 输出到日志：

```sh
python3 /填写Mac工具目录/rc11-acceptance-driver/mac-decrypt-full.py \
  --tool /填写Mac已核SHA的/copper-key-offline \
  --identity /填写新Mac合成密钥目录/copper-age-identity.txt \
  --archive /填写Mac备份目录/原文件名.copperbak \
  --receipt /填写Mac私有runtime/full-receipt.json \
  --report /填写Mac安全证据/full-macos-verification.json
```

此包装器只在 Darwin 上运行，调用正式 offline helper 的 age 真解密、内层校验，成功后记录工具/备份/回执 SHA、backupId 和平台；安全 report 不含 proof/私钥。Root 将**原始 receipt 私有传回** `R/full-mac-receipt.json`，安全 report 传回 `R/full-macos-verification.json`，然后在验收机：

```sh
sudo python3 "$D/phase-runner.py" full-mac-receipt \
  --receipt "$R/full-mac-receipt.json" --mac-report "$R/full-macos-verification.json"
sudo python3 "$D/phase-runner.py" advance
sudo python3 "$D/phase-runner.py" incremental
sudo python3 "$D/phase-runner.py" stage1 --identity /填写本轮私有server-runtime/新合成identity.txt
```

`advance` 追加真实收10、付20；`incremental` 创建正式 **v2 增量**并保留状态/sidecar。`stage1` 正式读取原 full+inc，使用 `release-recovery-rc11`、loopback18081，完成真解密、SQL导入、binlog回放及 expected/imported/staged 的表数、余额、附件、schema/FK比较。保存脱敏比较报告和连续链摘要。**VALIDATED 后不登录、不 API 请求旁路**；运行器只读正式 status 和比较文件。

下一步必须用可信 PTY：

```sh
sudo python3 "$D/phase-runner.py" switch1
```

读到生产工具确认提示后，准确输入：

```text
SWITCH copper-acceptance-rc11 release-recovery-rc11
```

不使用 `COPPER_TEST_MODE`、`COPPER_RESTORE_TEST_CONFIRM` 或注入标志。然后继续：

```sh
sudo python3 "$D/phase-runner.py" restored
sudo python3 "$D/phase-runner.py" continue
sudo python3 "$D/phase-runner.py" rebuild
sudo python3 "$D/phase-runner.py" new-full
```

`restored` 核增量阶段业务；`continue` 再真实销售出库0.123456kg、收5、付7；`rebuild` 调正式 `down`/`up`，核三容器全部重建、etc/mysql/files/backup和第一次切换 rollback 目录保留、附件字节不变，再做 API/SQL验收。`new-full` 显式创建新的 v1 full，重置旧 binlog chain 状态；不尝试从旧增量链续接。

把新的 full 与原 sidecar 传到 Mac，再执行上面实际 Mac 解密命令，改用**新的** archive/receipt/report 路径。不要复用第一次回执；将私有 receipt/report 传回 `R/new-full-mac-receipt.json` / `R/new-full-macos-verification.json`：

```sh
sudo python3 "$D/phase-runner.py" new-full-mac-receipt \
  --receipt "$R/new-full-mac-receipt.json" --mac-report "$R/new-full-macos-verification.json"
sudo python3 "$D/phase-runner.py" stage2 --identity /填写本轮私有server-runtime/新合成identity.txt
sudo python3 "$D/phase-runner.py" discard2
sudo python3 "$D/phase-runner.py" final
```

stage2 仅传新 full，不附旧 inc；使用 `release-rebackup-rc11`、loopback18082，保存实际 VALIDATED 和独立比较报告。无须切换/登录这个旁路。`discard2` 使用正式 `backup restore discard release-rebackup-rc11 --confirm 'DISCARD release-rebackup-rc11'` 删除第二旁路；保留第一次 `SWITCHED` 的 rollback/mysql/files。`final` 重新核 continued API/SQL和三份备份 SHA，完成时才写最终运行摘要。

| 阶段 | 库存kg | 库存成本 | 应收未收 | 应付未付 | 最少自动凭证 |
|---|---:|---:|---:|---:|---:|
| baseline | 8.123455 | 407.17 | 60.25 | 307.42 | 5 |
| incremental | 8.123455 | 407.17 | 50.25 | 287.42 | 7 |
| continued | 7.999999 | 400.98 | 55.14 | 280.42 | 11 |

失败时保留原文件、phase ledger和 API mutation journal；不要删 state 或改 expected 后重跑资金。先运行无网络检查：

```sh
sudo python3 "$D/phase-runner.py" inspect
sudo python3 "$D/api-fixture.py" inspect-state --state "$R/fixture-state.json"
```

Root 按实际 API/只读 SQL 判断最后请求是否已提交，再决定精确恢复步骤。`phase-runner.py` 失败记录不自动清除。原份备份、初次切换回滚槽及冷存的 RC10 资源不由此工具永久删除。浏览器/手机/真实客户验收另列，不能由本轮合成 API 流程冒充。
