#!/usr/bin/env python3
"""Read-only ordinary-file closed set verification."""
from pathlib import Path
import json,hashlib
ROOT=Path(__file__).resolve().parent
def verify():
 d=json.loads((ROOT/'driver-manifest.json').read_text());expected={row['path']:row for row in d['files']}
 if any(p.is_symlink() for p in ROOT.rglob('*')):raise RuntimeError('Symlink in driver package')
 actual={str(p.relative_to(ROOT)) for p in ROOT.rglob('*') if p.is_file()}
 if actual!=set(expected)|{'driver-manifest.json'}:raise RuntimeError('Driver closed set mismatch')
 for name,row in expected.items():
  data=(ROOT/name).read_bytes()
  if len(data)!=row['bytes'] or hashlib.sha256(data).hexdigest()!=row['sha256']:raise RuntimeError('Driver file changed: '+name)
 return {'status':'CLOSED_DRIVER_FILES_VERIFIED','files':len(actual),'runtimeAcceptance':'NOT_CLAIMED_BY_PACKAGE_VERIFICATION'}
if __name__=='__main__':print(json.dumps(verify()))
