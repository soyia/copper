#!/usr/bin/env python3
"""Offline diagnostics for the temporary driver; does not prove any deployed acceptance."""
import copy
import hashlib
import importlib.util
import json
from pathlib import Path
import subprocess
import sys
import tempfile
from decimal import Decimal as D

ROOT=Path(__file__).resolve().parent

def module(name,file):
    spec=importlib.util.spec_from_file_location(name,ROOT/file)
    result=importlib.util.module_from_spec(spec);spec.loader.exec_module(result);return result

api=module('fixture','api-fixture.py');backup=module('checkpoint','backup-checkpoint.py')
state={'synthetic':True,'siteId':'copper-offline-synthetic','partner':1,'product':2,'warehouse':3,'purchase':4,'inbound':5,'batch':6,'attachment':7,'snapshot':8,'snapshotAttachment':9,'marker':'OFFLINE_SYNTHETIC','phase':'baseline','phases':{}}
for phase,quantity,cost,ar,ap,count in [('baseline','8.123455','407.17','60.25','307.42',1),('incremental','8.123455','407.17','50.25','287.42',2),('continued','7.999999','400.98','55.14','280.42',3)]:
    state['phases'][phase]={'quantity':quantity,'amountCost':cost,'receivable':ar,'payable':ap,'sales':[10]+([11] if phase=='continued' else []),'outbounds':[20]+([21] if phase=='continued' else []),'receipts':list(range(30,30+count)),'supplierPayments':list(range(40,40+count))}

class FakeClient:
    def __init__(self,phase,missing_source=False,bad_attachment=False):
        self.phase=phase;self.facts=state['phases'][phase];self.calls=0;self.cookie_flags={};self.bad_attachment=bad_attachment
        pairs=[('INBOUND',5)]+[(('OUTBOUND'),x) for x in self.facts['outbounds'] for _ in range(2)]+[('PAYMENT',x) for x in self.facts['receipts']]+[('SUPPLIER_PAYMENT',x) for x in self.facts['supplierPayments']]
        if missing_source:pairs=[x for x in pairs if x!=('PAYMENT',30)]+[('SUPPLIER_PAYMENT',40)]
        self.vouchers=[{'sourceType':t,'sourceId':i,'debitTotal':D(1),'creditTotal':D(1)} for t,i in pairs]
    def get(self,path):
        self.calls+=1;f=self.facts
        if path=='/purchase-orders/4':return {'totalAmount':D('507.42'),'paidAmount':D('507.42')-D(f['payable'])}
        if path=='/inbounds/5':return {'status':'STOCKED'}
        if path.startswith('/sales-orders/'):
            return {'receivableAmount':D(f['receivable']) if path.endswith('/10') else D(0),'receivedAmount':D(0),'adjustedAmount':D(0)}
        if path.startswith('/inventory/batches?'):return [{'id':6,'quantityAvailable':f['quantity'],'amountCost':f['amountCost']}]
        if path.startswith('/outbounds/'):return {'status':'SHIPPED'}
        if path=='/accounting/generation-issues?status=OPEN':return []
        if path=='/accounting/vouchers':return self.vouchers
        raise AssertionError('unexpected offline path '+path)
    def request(self,method,path,binary=False):
        assert method=='GET' and binary
        return b'wrong synthetic bytes' if self.bad_attachment else api.PNG

def rejected(function,needle):
    try:function()
    except RuntimeError as e:assert needle in str(e),str(e)
    else:raise AssertionError('expected rejection: '+needle)

checks=[]
for phase in state['phases']:
    assert api.verify(FakeClient(phase),state,phase)['status']=='PASS';checks.append('offline verifier shape '+phase)
rejected(lambda:api.verify(FakeClient('baseline',missing_source=True),state,'baseline'),'automatic source vouchers missing');checks.append('duplicate source cannot hide another missing voucher')
rejected(lambda:api.verify(FakeClient('baseline',bad_attachment=True),state,'baseline'),'attachment hash mismatch');checks.append('wrong original/snapshot attachment rejected')
with tempfile.TemporaryDirectory(prefix='copper-offline-contract-') as tmp:
    root=Path(tmp);payload=b'SYNTHETIC UNIT INPUT; NOT AN ENCRYPTED BACKUP';archive=root/'synthetic.copperbak';archive.write_bytes(payload);h=hashlib.sha256(payload).hexdigest();(root/'synthetic.copperbak.sha256').write_text(h+'  synthetic.copperbak\n');status={'formatVersion':'copper-backup/v1','archive':archive.name,'backupId':'synthetic-a','size':len(payload),'sha256':h};source=root/'last-success.json'
    def save():source.write_text(json.dumps(status))
    save();first=root/'first.json';assert backup.checkpoint(root,first,'copper-backup/v1')==archive.resolve();assert first.stat().st_mode&0o777==0o600;checks.append('checkpoint basename/root/hash/size and private state')
    rejected(lambda:backup.checkpoint(root,root/'bad-format.json','copper-backup/v2'),'format does not match');checks.append('wrong full/incremental format rejected')
    rejected(lambda:backup.checkpoint(root,root/'reused.json','copper-backup/v1',[first]),'reused a prior');checks.append('stale backup ID rejected')
    status['archive']='../outside.copperbak';save();rejected(lambda:backup.checkpoint(root,root/'escape.json','copper-backup/v1'),'basename');checks.append('backup basename escape rejected')
    status['archive']=archive.name;status['sha256']='0'*64;save();rejected(lambda:backup.checkpoint(root,root/'bad-hash.json','copper-backup/v1'),'SHA256 mismatch');checks.append('archive hash mismatch rejected')
    status['sha256']=h;save();archive.unlink();archive.symlink_to(first);rejected(lambda:backup.checkpoint(root,root/'symlink.json','copper-backup/v1'),'ordinary files');checks.append('symlink archive rejected')
    text=(ROOT/'schema-proof.sh').read_text();program=text.split("<<'PY'\n",1)[1].split('\nPY\n',1)[0];statefile=root/'state.json';statefile.write_text(json.dumps(state));sql=root/'fixture.sql'
    subprocess.run([sys.executable,'-',str(statefile),str(sql),state['siteId'],'continued'],input=program,text=True,check=True)
    sqltext=sql.read_text();assert "SELECT 'stock_amount_cost', amount_cost FROM stock_balance WHERE product_id=2 AND warehouse_id=3" in sqltext;assert all(line.startswith('SELECT ') for line in sqltext.splitlines());checks.append('schema proof SQL generation read-only plus stock cost')
print(json.dumps({'status':'OFFLINE_DIAGNOSTICS_PASS','checks':len(checks),'checkNames':checks,'networkUsed':False,'databaseUsed':False,'runtimeAcceptance':'NOT_RUN'},indent=2))
