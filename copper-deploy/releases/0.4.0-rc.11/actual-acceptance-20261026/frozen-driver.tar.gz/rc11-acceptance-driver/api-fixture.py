#!/usr/bin/env python3
"""Synthetic release fixture through current production HTTP APIs; never executes SQL."""
import argparse
import base64
from decimal import Decimal, ROUND_HALF_UP
import hashlib
import json
import os
from pathlib import Path
import re
import secrets
import stat
import subprocess
import tempfile
from datetime import date, datetime, timezone
from urllib.parse import urlencode, urlsplit

D = Decimal
PNG = base64.b64decode('iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAwMCAO+jRZkAAAAASUVORK5CYII=')
PNG_SHA = hashlib.sha256(PNG).hexdigest()
COST, PRICE = D('50.1234'), D('80.1234')
PURCHASED, SOLD = D('10.123456'), D('2.000001')
MARKER = 'INTERNAL_REHEARSAL_ONLY SYNTHETIC_RELEASE_ACCEPTANCE'


def money(value):
    return D(value).quantize(D('.01'), rounding=ROUND_HALF_UP)


def write_private(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True, mode=0o700)
    if path.is_symlink():
        raise RuntimeError('refusing symlink output')
    descriptor, temporary = tempfile.mkstemp(prefix='.'+path.name+'-', dir=path.parent)
    try:
        with os.fdopen(descriptor, 'w') as out:
            json.dump(value, out, ensure_ascii=False, indent=2, default=str)
            out.write('\n')
        os.replace(temporary, path)
    finally:
        Path(temporary).unlink(missing_ok=True)


def read_private(path):
    path = Path(path)
    if path.is_symlink() or not path.is_file() or stat.S_IMODE(path.stat().st_mode) & 0o077:
        raise RuntimeError('credential/state input must be a private regular file (0600)')
    text = path.read_text()
    if text.lstrip().startswith('{'):
        return json.loads(text)
    return dict(line.split('=', 1) for line in text.splitlines() if '=' in line)


class Client:
    def __init__(self, args):
        self.args = args
        self.base = args.base_url.rstrip('/')
        self.url = urlsplit(self.base)
        if self.url.scheme not in ('http', 'https') or self.url.username or self.url.password or self.url.query or self.url.fragment:
            raise RuntimeError('base URL must be a plain Web origin with optional path')
        if self.url.port in (8191, 3306):
            raise RuntimeError('use Web ingress; backend/MySQL host ports are forbidden')
        if self.url.scheme == 'http' and self.url.hostname not in ('localhost', '127.0.0.1', '::1'):
            raise RuntimeError('HTTP is allowed only for the isolated loopback Web listener')
        args.credentials.parent.mkdir(parents=True, exist_ok=True, mode=0o700)
        self.work = tempfile.TemporaryDirectory(prefix='copper-api-private-', dir=args.credentials.parent)
        self.root = Path(self.work.name)
        self.jar = self.root/'cookies'
        self.jar.touch(mode=0o600)
        self.calls = 0
        self.cookie_flags = {}
        self.journal_path = args.state.with_suffix(".journal.json") if args.state else None

    def close(self):
        self.work.cleanup()

    def journal(self, event):
        if self.journal_path is None:
            return
        doc = read_private(self.journal_path) if self.journal_path.exists() else {
            'format':'copper-api-mutation-journal/v1', 'siteId':self.args.site_id, 'events':[]}
        if doc.get('siteId') != self.args.site_id:
            raise RuntimeError('mutation journal belongs to another site')
        doc['events'].append({'at':datetime.now(timezone.utc).isoformat(), **event})
        write_private(self.journal_path, doc)

    def request(self, method, path, body=None, binary=False, upload=False):
        self.calls += 1
        headers, output = self.root/'headers', self.root/'response'
        args = ['curl', '--silent', '--show-error', '--max-time', '90', '--request', method,
                '--cookie', str(self.jar), '--cookie-jar', str(self.jar),
                '--dump-header', str(headers), '--output', str(output), '--write-out', '%{http_code}']
        if self.args.ca_file:
            args += ['--cacert', str(self.args.ca_file)]
        if self.args.connect_ip:
            args += ['--resolve', f'{self.url.hostname}:{self.url.port or (443 if self.url.scheme=="https" else 80)}:{self.args.connect_ip}']
        if method not in ('GET', 'HEAD') and self.url.scheme == 'https':
            args += ['--header', 'Origin: '+self.url.scheme+'://'+self.url.netloc]
        payload = None
        if upload:
            sample = self.root/'synthetic-placeholder.png'
            sample.write_bytes(PNG)
            args += ['--form', 'file=@'+str(sample)+';type=image/png;filename=synthetic-release-placeholder.png']
        elif body is not None:
            args += ['--header', 'Content-Type: application/json', '--data-binary', '@-']
            payload = json.dumps(body, default=str).encode()
        args += [self.base + '/api' + path]
        mutation = method not in ('GET','HEAD') and not path.startswith('/auth/')
        event = {'requestId':secrets.token_hex(6), 'method':method, 'path':path}
        if mutation:
            # The checkpoint precedes the request. A timeout is an unknown outcome,
            # so a later operator reconciles the returned IDs instead of retrying money.
            self.journal({**event, 'outcome':'ATTEMPTING'})
        result = subprocess.run(args, input=payload, capture_output=True)
        # Never print request bodies, cookies, Set-Cookie headers or login responses.
        status = result.stdout.decode(errors='replace')
        if result.returncode or not status.isdigit():
            if mutation: self.journal({**event, 'outcome':'UNKNOWN_TRANSPORT_OUTCOME'})
            raise RuntimeError(f'HTTP transport failed for {method} {path}; do not repeat mutations; inspect private journal')
        if not 200 <= int(status) < 300:
            if mutation: self.journal({**event, 'outcome':'HTTP_ERROR', 'httpStatus':int(status)})
            detail = ''
            if not path.startswith('/auth/'):
                try:
                    error = json.loads(output.read_bytes())
                    detail = ': ' + str(error.get('message','request rejected'))[:240]
                except (ValueError, OSError):
                    pass
            raise RuntimeError(f'{method} {path}: HTTP {status}{detail}')
        if path == '/auth/login':
            header_text = headers.read_text().lower()
            self.cookie_flags = {'secure': '; secure' in header_text, 'httpOnly': '; httponly' in header_text,
                                 'sameSiteStrict': 'samesite=strict' in header_text}
        data = output.read_bytes()
        if binary:
            return data
        doc = json.loads(data, parse_float=D)
        if doc.get('code') != 0:
            message = str(doc.get('message', 'business request rejected'))[:240]
            if mutation: self.journal({**event, 'outcome':'BUSINESS_REJECTED', 'apiCode':doc.get('code')})
            raise RuntimeError(f'{method} {path}: business error: {message}')
        if mutation:
            data_id = doc.get('data',{}).get('id') if isinstance(doc.get('data'),dict) else None
            self.journal({**event, 'outcome':'COMMITTED', 'returnedId':data_id})
        return doc.get('data')

    def get(self, path):
        return self.request('GET', path)

    def post(self, path, body=None):
        return self.request('POST', path, {} if body is None else body)

    def create(self, path, body):
        return self.post(path, body)['id']

    def login(self, credentials):
        session = self.post('/auth/login', {'username':credentials['username'], 'password':credentials['password']})
        if not all(self.cookie_flags.values()):
            raise RuntimeError('production session cookie attributes are incomplete')
        return session


def expect(value, expected, label):
    if D(str(value)) != D(str(expected)):
        raise RuntimeError(f'{label}: expected {expected}, actual {value}')


def checkpoint(client, state, action):
    state['lastCheckpoint'] = {'action':action, 'at':datetime.now(timezone.utc).isoformat()}
    write_private(client.args.state, state)


def sale(client, state, quantity, suffix):
    sale_id = client.create('/sales-orders', {
        'title':state['marker']+'-'+suffix, 'customerId':state['partner'], 'addressId':state['address'],
        'businessDate':state['date'], 'deliveryPlanDate':state['date'], 'fulfillmentWarehouseId':state['warehouse'],
        'discountRate':0, 'adjustmentAmount':0, 'paymentTerm':'POSTPAID', 'shipmentPaymentPolicy':'NONE',
        'depositMode':'AMOUNT', 'depositRate':0, 'requiredDepositAmount':0, 'memo':MARKER,
        'items':[{'productId':state['product'], 'quantity':str(quantity), 'quantityUnit':'kg',
                  'priceUnit':'kg', 'packageUnit':'', 'noCharge':False, 'unitPrice':str(PRICE)}]})
    state['sales'].append(sale_id)
    checkpoint(client,state,'sales-created-'+suffix)
    client.post(f'/sales-orders/{sale_id}/confirm')
    detail = client.get(f'/sales-orders/{sale_id}')
    sale_item = detail['items'][0]['id']
    outbound = {
        'salesOrderId':sale_id, 'customerId':state['partner'], 'addressId':state['address'],
        'warehouseId':state['warehouse'], 'businessDate':state['date'], 'actualShippedAt':state['date']+'T10:00:00',
        'sourceChannel':'SALES_ORDER', 'entryMode':'NORMAL', 'completenessStatus':'COMPLETE',
        'lateEntryReason':'', 'pricePending':False, 'shipmentPaymentPolicy':'NONE', 'shipmentControlAmount':0,
        'confirmNow':True, 'allowOverShipment':False, 'overShipmentReason':'',
        'idempotencyKey':state['marker']+'-'+suffix, 'discountRate':0, 'adjustmentAmount':0, 'memo':MARKER,
        'items':[{'salesOrderItemId':sale_item, 'batchId':state['batch'], 'quantity':str(quantity),
                  'quantityUnit':'kg', 'priceUnit':'kg', 'packageUnit':'', 'unitPrice':str(PRICE), 'packageInstanceIds':[]}]}
    outbound_id = client.create('/outbounds', outbound)
    state['outbounds'].append(outbound_id)
    checkpoint(client,state,'outbound-shipped-'+suffix)
    # Exercise supported idempotency without creating duplicate stock/AR movements.
    if client.create('/outbounds', outbound) != outbound_id:
        raise RuntimeError('repeated outbound did not return its original document')
    return sale_id, outbound_id


def funds(client, state, received, paid, suffix):
    receipt = client.create('/payments', {'customerId':state['partner'], 'salesOrderId':state['sales'][0],
        'amount':str(received), 'paymentMethod':'CASH', 'receivedDate':state['date'], 'memo':MARKER+' '+suffix})
    state['receipts'].append(receipt)
    checkpoint(client,state,'receipt-committed-'+suffix)
    payment = client.create('/supplier-payments', {'supplierId':state['partner'], 'purchaseOrderId':state['purchase'],
        'amount':str(paid), 'paymentMethod':'CASH', 'paidDate':state['date'], 'memo':MARKER+' '+suffix})
    state['supplierPayments'].append(payment)
    checkpoint(client,state,'supplier-payment-committed-'+suffix)


def remember(state, phase, quantity, receivable, payable, amount_cost):
    state['phase'] = phase
    state['operationInProgress'] = None
    state['phases'][phase] = {'quantity':str(quantity), 'receivable':str(receivable), 'payable':str(payable),
        'amountCost':str(amount_cost), 'sales':list(state['sales']), 'outbounds':list(state['outbounds']),
        'receipts':list(state['receipts']), 'supplierPayments':list(state['supplierPayments'])}


def seed(client, args):
    if args.state.exists():
        raise RuntimeError('seed state already exists; do not blindly repeat non-idempotent master/payment creation')
    purchase_rows, sales_rows = client.get('/purchase-orders'), client.get('/sales-orders')
    if not isinstance(purchase_rows,list) or not isinstance(sales_rows,list):
        raise RuntimeError('purchase/sales list API contract changed; expected unpaged data arrays')
    if purchase_rows or sales_rows:
        raise RuntimeError('synthetic seed requires blank business orders on the isolated acceptance site')
    state = {'format':'copper-http-recovery-fixture/v1', 'synthetic':True, 'siteId':args.site_id,
             'marker':'SYNTH'+secrets.token_hex(8).upper(), 'date':date.today().isoformat(),
             'sales':[], 'outbounds':[], 'receipts':[], 'supplierPayments':[], 'phases':{},
             'operationInProgress':'seed'}
    # Persist identifiers after each checkpoint so a failed rehearsal is inspected, never blindly rerun.
    def save():
        checkpoint(client,state,'seed-checkpoint')
    save()
    state['partner'] = client.create('/partners', {'typeMask':3, 'entityType':'INDIVIDUAL',
        'name':state['marker']+'虚构往来单位', 'status':'ENABLED', 'customerStatus':'ENABLED',
        'supplierStatus':'ENABLED', 'creditLimit':100000, 'customerSettlementMethod':'PER_ORDER',
        'customerTaxIncluded':True, 'customerInvoiceType':'NONE', 'customerTaxRate':0,
        'supplierTaxIncluded':True, 'supplierInvoiceType':'NONE', 'supplierTaxRate':0,
        'contactPerson':'虚构验收人员', 'memo':MARKER})
    save()
    state['address'] = client.create('/addresses', {'partnerId':state['partner'], 'name':'虚构收货点',
        'addressType':'RECEIVING', 'detail':'SYNTHETIC ACCEPTANCE ADDRESS', 'contactPerson':'虚构验收人员',
        'firstChoice':True, 'memo':MARKER, 'status':'ENABLED'})
    save()
    state['warehouse'] = client.create('/warehouses', {'name':state['marker']+'虚构仓', 'location':MARKER, 'status':'ENABLED'})
    save()
    categories = [v for v in client.get('/product-categories') if v.get('status') == 'ENABLED']
    if not categories:
        raise RuntimeError('no enabled product category')
    category = next((v for v in categories if v['name']=='电解铜'), categories[0])['id']
    state['series'] = client.create('/product-series', {'categoryId':category, 'code':state['marker'],
        'name':state['marker']+'虚构经营品系列', 'aliasNames':'', 'status':'ENABLED'})
    save()
    state['product'] = client.create('/products', {'categoryId':category, 'productSeriesId':state['series'],
        'sku':state['marker'], 'name':state['marker']+'虚构铜料', 'grade':'', 'temper':'', 'standard':'',
        'spec':'', 'attributeJson':'{}', 'unit':'kg', 'defaultPrice':str(PRICE),
        'status':'ENABLED', 'fieldValues':[], 'identityStatus':'PUBLISHED'})
    save()
    state['purchase'] = client.create('/purchase-orders', {'supplierId':state['partner'],
        'businessDate':state['date'], 'expectedDate':state['date'], 'expectedWarehouseId':state['warehouse'],
        'sourceType':'PHONE', 'sourceNote':MARKER, 'discountRate':0, 'adjustmentAmount':0, 'memo':MARKER,
        'items':[{'productId':state['product'], 'quantity':str(PURCHASED), 'quantityUnit':'kg',
                  'priceUnit':'kg', 'packageUnit':'', 'noCharge':False, 'unitPrice':str(COST)}]})
    save()
    client.post(f'/purchase-orders/{state["purchase"]}/confirm')
    purchase_item = client.get(f'/purchase-orders/{state["purchase"]}')['items'][0]['id']
    state['inbound'] = client.create('/inbounds', {'purchaseOrderId':state['purchase'], 'supplierId':state['partner'],
        'warehouseId':state['warehouse'], 'sourceType':'PURCHASE_ORDER', 'sourceNote':MARKER,
        'businessDate':state['date'], 'sendDate':state['date'], 'sendNumber':state['marker'],
        'discountRate':0, 'adjustmentAmount':0, 'memo':MARKER,
        'items':[{'productId':state['product'], 'purchaseOrderItemId':purchase_item, 'batchNo':state['marker'],
                  'serialNumber':'', 'quantity':str(PURCHASED), 'quantityUnit':'kg', 'priceUnit':'kg',
                  'packageUnit':'', 'packageBarcode':'', 'unitCost':str(COST),
                  'packageInstances':[], 'productionDate':state['date']}]})
    save()
    attachment = client.request('POST',f'/inbounds/{state["inbound"]}/attachments', upload=True)
    state['attachment'] = attachment['id']
    state['attachmentSha256'] = PNG_SHA
    save()
    client.post(f'/inbounds/{state["inbound"]}/submit')
    client.post(f'/inbounds/{state["inbound"]}/audit', {'approved':True, 'reason':''})
    inbound = client.get(f'/inbounds/{state["inbound"]}')
    state['batch'] = inbound['items'][0]['inventoryBatchId']
    logs = client.get(f'/inbounds/{state["inbound"]}/audit-logs')
    snapshot_id = next(v['snapshotId'] for v in logs if v.get('snapshotId'))
    log_id = next(v['id'] for v in logs if v.get('snapshotId')==snapshot_id)
    snapshot = client.get(f'/inbounds/{state["inbound"]}/audit-logs/{log_id}')['snapshot']
    state['snapshot'], state['snapshotAttachment'] = snapshot_id, snapshot['attachments'][0]['id']
    save()
    sales, outbound = sale(client, state, SOLD, 'SEED')
    funds(client,state,D('100'),D('200'),'SEED')
    remember(state,'baseline',PURCHASED-SOLD,money(SOLD*PRICE)-100,money(PURCHASED*COST)-200,
             money(PURCHASED*COST)-money(SOLD*COST))
    save()
    return state


def verify(client, state, phase):
    expected = state['phases'][phase]
    purchase = client.get(f'/purchase-orders/{state["purchase"]}')
    inbound = client.get(f'/inbounds/{state["inbound"]}')
    if inbound['status'] != 'STOCKED':
        raise RuntimeError('inbound is not stocked')
    expect(purchase['totalAmount']-purchase['paidAmount'], expected['payable'], 'AP outstanding')
    sales = [client.get(f'/sales-orders/{value}') for value in expected['sales']]
    outstanding = sum((D(str(v['receivableAmount']))-D(str(v['receivedAmount']))-D(str(v['adjustedAmount'])) for v in sales), D(0))
    expect(outstanding, expected['receivable'], 'AR outstanding')
    batches = client.get('/inventory/batches?'+urlencode({'productId':state['product'],'warehouseId':state['warehouse']}))
    batch = next(v for v in batches if v['id']==state['batch'])
    expect(batch['quantityAvailable'], expected['quantity'], 'batch remaining quantity')
    expect(batch['amountCost'], expected['amountCost'], 'batch remaining cost')
    for value in expected['outbounds']:
        if client.get(f'/outbounds/{value}')['status'] != 'SHIPPED':
            raise RuntimeError('outbound is not shipped')
    for path in (f'/inbounds/{state["inbound"]}/attachments/{state["attachment"]}/content',
                 f'/inbounds/{state["inbound"]}/review-snapshots/{state["snapshot"]}/attachments/{state["snapshotAttachment"]}/content'):
        if hashlib.sha256(client.request('GET',path,binary=True)).hexdigest()!=PNG_SHA:
            raise RuntimeError('original or review snapshot attachment hash mismatch')
    if client.get('/accounting/generation-issues?status=OPEN'):
        raise RuntimeError('automatic accounting generation has open issues')
    source_ids = {('INBOUND',state['inbound']), *(('OUTBOUND',i) for i in expected['outbounds']),
                  *(('PAYMENT',i) for i in expected['receipts']), *(('SUPPLIER_PAYMENT',i) for i in expected['supplierPayments'])}
    vouchers = client.get('/accounting/vouchers')
    matched = [v for v in vouchers if (v['sourceType'],v['sourceId']) in source_ids]
    for value in matched:
        expect(value['debitTotal'], value['creditTotal'], 'automatic voucher balance')
    # A duplicate for one source must not hide a missing voucher for another source.
    required_counts = {source:2 if source[0]=='OUTBOUND' else 1 for source in source_ids}
    for source, required in required_counts.items():
        actual = sum((v['sourceType'],v['sourceId'])==source for v in matched)
        if actual < required:
            raise RuntimeError(f"automatic source vouchers missing for {source[0]} id={source[1]}: expected at least {required}, actual {actual}")
    # The SQL proof supplements this with raw posting/voucher and balance checks.
    return {'format':'copper-compose-api-acceptance/v1', 'status':'PASS', 'synthetic':True,
        'siteId':state['siteId'], 'phase':phase, 'fixtureMarker':state['marker'],
        'expected':expected, 'verifiedAttachmentCopies':2, 'attachmentSha256':PNG_SHA,
        'automaticVouchersVisible':len(matched), 'cookieFlags':client.cookie_flags,
        'apiCalls':client.calls, 'customerDataUsed':False, 'schemaAndBackupRuntimeProof':'SEPARATE_PRODUCTION_TOOLS_REQUIRED'}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('command', choices=('bootstrap','seed','advance','continue','verify','inspect-state','self-check'))
    parser.add_argument('--base-url',default='http://localhost:18080')
    parser.add_argument('--connect-ip')
    parser.add_argument('--ca-file', type=Path)
    parser.add_argument('--site-id')
    parser.add_argument('--synthetic-site-ack')
    parser.add_argument('--initial-credentials',type=Path)
    parser.add_argument('--credentials',type=Path)
    parser.add_argument('--state',type=Path)
    parser.add_argument('--phase',choices=('baseline','incremental','continued'))
    parser.add_argument('--evidence',type=Path)
    args = parser.parse_args()
    if args.command=='self-check':
        assert money(PURCHASED*COST)==D('507.42') and money(SOLD*PRICE)==D('160.25')
        assert PURCHASED-SOLD==D('8.123455') and money(D('.123456')*PRICE)==D('9.89')
        print('STATIC_ARITHMETIC_AND_ATTACHMENT=PASS no_network=true')
        return
    if args.command=='inspect-state':
        if not args.state:
            parser.error('inspect-state requires --state only; it never opens an HTTP client')
        state = read_private(args.state)
        journal_path=args.state.with_suffix('.journal.json')
        journal=read_private(journal_path) if journal_path.exists() else {'events':[]}
        print(json.dumps({'siteId':state.get('siteId'), 'phase':state.get('phase'),
            'operationInProgress':state.get('operationInProgress'), 'lastCheckpoint':state.get('lastCheckpoint'),
            'knownIds':{key:state.get(key) for key in ('partner','product','warehouse','purchase','inbound','sales','outbounds','receipts','supplierPayments')},
            'recentMutationEvents':journal['events'][-10:], 'networkUsed':False},ensure_ascii=False))
        return
    if not args.site_id or not re.fullmatch(r'copper-[a-z0-9-]+',args.site_id):
        parser.error('--site-id must be the isolated copper-* site ID')
    if args.command!='verify' and args.synthetic_site_ack!=args.site_id:
        parser.error('mutations require --synthetic-site-ack matching the owned isolated site ID')
    if not args.credentials or (args.command!='bootstrap' and not args.state):
        parser.error('--credentials and --state are required')
    client = Client(args)
    try:
        if args.command=='bootstrap':
            if not args.initial_credentials or args.credentials.exists():
                raise RuntimeError('bootstrap requires initial credentials and a new private credentials output')
            credentials = read_private(args.initial_credentials)
            session = client.login(credentials)
            if not session['passwordChangeRequired']:
                raise RuntimeError('initial account was already changed; supply its current private credentials')
            pending=args.credentials.with_suffix('.pending.json')
            if pending.exists():
                raise RuntimeError('pending private password checkpoint exists; reconcile its login before retrying bootstrap')
            replacement = {'username':credentials['username'],'password':'Acceptance!'+secrets.token_hex(20)+'aZ9'}
            write_private(pending,replacement)
            client.post('/auth/change-password', {'currentPassword':credentials['password'],'newPassword':replacement['password']})
            os.replace(pending,args.credentials)
            client.jar.write_text('')
            if client.login(replacement)['passwordChangeRequired']:
                raise RuntimeError('initial password change not effective')
            print('BOOTSTRAP=PASS credentials_written_privately=true')
            return
        if client.login(read_private(args.credentials))['passwordChangeRequired']:
            raise RuntimeError('change initial password first')
        if args.command=='seed':
            state=seed(client,args)
        else:
            state=read_private(args.state)
            if state.get('synthetic') is not True or state.get('siteId')!=args.site_id:
                raise RuntimeError('state is not bound to this synthetic site')
            if args.command in ('advance','continue') and state.get('operationInProgress'):
                raise RuntimeError('previous mutation phase is incomplete; inspect-state and reconcile before any retry')
            if args.command=='advance':
                if state['phase']!='baseline':
                    raise RuntimeError('advance is allowed once after the full backup')
                state['operationInProgress']='advance'
                checkpoint(client,state,'advance-started')
                funds(client,state,D('10'),D('20'),'INCREMENTAL')
                remember(state,'incremental',D('8.123455'),D('50.25'),D('287.42'),D('407.17'))
                write_private(args.state,state)
            elif args.command=='continue':
                if state['phase']!='incremental':
                    raise RuntimeError('continue requires the verified incremental recovery phase')
                state['operationInProgress']='continue'
                checkpoint(client,state,'continue-started')
                sales,outbound=sale(client,state,D('.123456'),'AFTER-RESTORE')
                funds(client,state,D('5'),D('7'),'AFTER-RESTORE')
                remember(state,'continued',D('7.999999'),D('55.14'),D('280.42'),D('400.98'))
                write_private(args.state,state)
        report=verify(client,state,args.phase or state['phase'])
        if args.evidence:
            write_private(args.evidence,report)
        print(json.dumps({'status':report['status'],'phase':report['phase'],'quantity':report['expected']['quantity'],
                          'receivable':report['expected']['receivable'],'payable':report['expected']['payable'],
                          'attachments':2,'synthetic':True}))
    finally:
        client.close()


if __name__=='__main__':
    main()
